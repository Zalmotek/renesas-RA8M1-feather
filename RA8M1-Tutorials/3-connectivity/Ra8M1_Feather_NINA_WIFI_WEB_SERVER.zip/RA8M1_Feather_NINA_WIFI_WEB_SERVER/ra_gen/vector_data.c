/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = iic_master_rxi_isr, /* IIC1 RXI (Receive data full) */
            [1] = iic_master_txi_isr, /* IIC1 TXI (Transmit data empty) */
            [2] = iic_master_tei_isr, /* IIC1 TEI (Transmit end) */
            [3] = iic_master_eri_isr, /* IIC1 ERI (Transfer error) */
            [4] = sci_b_uart_rxi_isr, /* SCI2 RXI (Receive data full) */
            [5] = sci_b_uart_txi_isr, /* SCI2 TXI (Transmit data empty) */
            [6] = sci_b_uart_tei_isr, /* SCI2 TEI (Transmit end) */
            [7] = sci_b_uart_eri_isr, /* SCI2 ERI (Receive error) */
            [8] = spi_b_rxi_isr, /* SPI1 RXI (Receive buffer full) */
            [9] = spi_b_txi_isr, /* SPI1 TXI (Transmit buffer empty) */
            [10] = spi_b_tei_isr, /* SPI1 TEI (Transmission complete event) */
            [11] = spi_b_eri_isr, /* SPI1 ERI (Error) */
            [12] = agt_int_isr, /* AGT0 INT (AGT interrupt) */
            [13] = r_icu_isr, /* ICU IRQ6 (External pin interrupt 6) */
            [14] = r_icu_isr, /* ICU IRQ8 (External pin interrupt 8) */
            [15] = r_icu_isr, /* ICU IRQ9 (External pin interrupt 9) */
            [16] = sci_b_uart_rxi_isr, /* SCI0 RXI (Receive data full) */
            [17] = sci_b_uart_txi_isr, /* SCI0 TXI (Transmit data empty) */
            [18] = sci_b_uart_tei_isr, /* SCI0 TEI (Transmit end) */
            [19] = sci_b_uart_eri_isr, /* SCI0 ERI (Receive error) */
            [20] = sci_b_uart_rxi_isr, /* SCI4 RXI (Receive data full) */
            [21] = sci_b_uart_txi_isr, /* SCI4 TXI (Transmit data empty) */
            [22] = sci_b_uart_tei_isr, /* SCI4 TEI (Transmit end) */
            [23] = sci_b_uart_eri_isr, /* SCI4 ERI (Receive error) */
            [24] = usbfs_interrupt_handler, /* USBFS INT (USBFS interrupt) */
            [25] = usbfs_resume_handler, /* USBFS RESUME (USBFS resume interrupt) */
            [26] = usbfs_d0fifo_handler, /* USBFS FIFO 0 (DMA transfer request 0) */
            [27] = usbfs_d1fifo_handler, /* USBFS FIFO 1 (DMA transfer request 1) */
            [28] = usbhs_interrupt_handler, /* USBHS USB INT RESUME (USBHS interrupt) */
            [29] = usbhs_d0fifo_handler, /* USBHS FIFO 0 (DMA transfer request 0) */
            [30] = usbhs_d1fifo_handler, /* USBHS FIFO 1 (DMA transfer request 1) */
        };
        #if BSP_FEATURE_ICU_HAS_IELSR
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
            [0] = BSP_PRV_VECT_ENUM(EVENT_IIC1_RXI,GROUP0), /* IIC1 RXI (Receive data full) */
            [1] = BSP_PRV_VECT_ENUM(EVENT_IIC1_TXI,GROUP1), /* IIC1 TXI (Transmit data empty) */
            [2] = BSP_PRV_VECT_ENUM(EVENT_IIC1_TEI,GROUP2), /* IIC1 TEI (Transmit end) */
            [3] = BSP_PRV_VECT_ENUM(EVENT_IIC1_ERI,GROUP3), /* IIC1 ERI (Transfer error) */
            [4] = BSP_PRV_VECT_ENUM(EVENT_SCI2_RXI,GROUP4), /* SCI2 RXI (Receive data full) */
            [5] = BSP_PRV_VECT_ENUM(EVENT_SCI2_TXI,GROUP5), /* SCI2 TXI (Transmit data empty) */
            [6] = BSP_PRV_VECT_ENUM(EVENT_SCI2_TEI,GROUP6), /* SCI2 TEI (Transmit end) */
            [7] = BSP_PRV_VECT_ENUM(EVENT_SCI2_ERI,GROUP7), /* SCI2 ERI (Receive error) */
            [8] = BSP_PRV_VECT_ENUM(EVENT_SPI1_RXI,GROUP0), /* SPI1 RXI (Receive buffer full) */
            [9] = BSP_PRV_VECT_ENUM(EVENT_SPI1_TXI,GROUP1), /* SPI1 TXI (Transmit buffer empty) */
            [10] = BSP_PRV_VECT_ENUM(EVENT_SPI1_TEI,GROUP2), /* SPI1 TEI (Transmission complete event) */
            [11] = BSP_PRV_VECT_ENUM(EVENT_SPI1_ERI,GROUP3), /* SPI1 ERI (Error) */
            [12] = BSP_PRV_VECT_ENUM(EVENT_AGT0_INT,GROUP4), /* AGT0 INT (AGT interrupt) */
            [13] = BSP_PRV_VECT_ENUM(EVENT_ICU_IRQ6,GROUP5), /* ICU IRQ6 (External pin interrupt 6) */
            [14] = BSP_PRV_VECT_ENUM(EVENT_ICU_IRQ8,GROUP6), /* ICU IRQ8 (External pin interrupt 8) */
            [15] = BSP_PRV_VECT_ENUM(EVENT_ICU_IRQ9,GROUP7), /* ICU IRQ9 (External pin interrupt 9) */
            [16] = BSP_PRV_VECT_ENUM(EVENT_SCI0_RXI,GROUP0), /* SCI0 RXI (Receive data full) */
            [17] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TXI,GROUP1), /* SCI0 TXI (Transmit data empty) */
            [18] = BSP_PRV_VECT_ENUM(EVENT_SCI0_TEI,GROUP2), /* SCI0 TEI (Transmit end) */
            [19] = BSP_PRV_VECT_ENUM(EVENT_SCI0_ERI,GROUP3), /* SCI0 ERI (Receive error) */
            [20] = BSP_PRV_VECT_ENUM(EVENT_SCI4_RXI,GROUP4), /* SCI4 RXI (Receive data full) */
            [21] = BSP_PRV_VECT_ENUM(EVENT_SCI4_TXI,GROUP5), /* SCI4 TXI (Transmit data empty) */
            [22] = BSP_PRV_VECT_ENUM(EVENT_SCI4_TEI,GROUP6), /* SCI4 TEI (Transmit end) */
            [23] = BSP_PRV_VECT_ENUM(EVENT_SCI4_ERI,GROUP7), /* SCI4 ERI (Receive error) */
            [24] = BSP_PRV_VECT_ENUM(EVENT_USBFS_INT,GROUP0), /* USBFS INT (USBFS interrupt) */
            [25] = BSP_PRV_VECT_ENUM(EVENT_USBFS_RESUME,GROUP1), /* USBFS RESUME (USBFS resume interrupt) */
            [26] = BSP_PRV_VECT_ENUM(EVENT_USBFS_FIFO_0,GROUP2), /* USBFS FIFO 0 (DMA transfer request 0) */
            [27] = BSP_PRV_VECT_ENUM(EVENT_USBFS_FIFO_1,GROUP3), /* USBFS FIFO 1 (DMA transfer request 1) */
            [28] = BSP_PRV_VECT_ENUM(EVENT_USBHS_USB_INT_RESUME,GROUP4), /* USBHS USB INT RESUME (USBHS interrupt) */
            [29] = BSP_PRV_VECT_ENUM(EVENT_USBHS_FIFO_0,GROUP5), /* USBHS FIFO 0 (DMA transfer request 0) */
            [30] = BSP_PRV_VECT_ENUM(EVENT_USBHS_FIFO_1,GROUP6), /* USBHS FIFO 1 (DMA transfer request 1) */
        };
        #endif
        #endif
