/*
 * arduino_secrets.h
 *
 *  Created on: Apr 25, 2025
 *      Author: alex
 */

#ifndef ARDUINO_SECRETS_H_
#define ARDUINO_SECRETS_H_

#define SECRET_SSID "Zalmotek"
#define SECRET_PASS "alpaca13"

#endif /* ARDUINO_SECRETS_H_ */
