#include "main_thread.h"
#include <Arduino.h>
#include <SPI.h>
#include <WiFiNINA.h>
#include <Wire.h>

#include "arduino_secrets.h"

char ssid[] = SECRET_SSID;
char pass[] = SECRET_PASS;
int keyIndex = 0;

int status = WL_IDLE_STATUS;
WiFiServer server(80);
byte deviceAddress = 0x10; // TF-Luna I2C address

void printWifiStatus() {
  Serial.print("SSID: ");
  Serial.println(WiFi.SSID());
  IPAddress ip = WiFi.localIP();
  Serial.print("IP Address: ");
  Serial.println(ip);
  long rssi = WiFi.RSSI();
  Serial.print("signal strength (RSSI):");
  Serial.print(rssi);
  Serial.println(" dBm");
}

void main_thread_entry(void *pvParameters) {
  FSP_PARAMETER_NOT_USED(pvParameters);

  Serial.begin(115200);
  while (!Serial) {;}

  Wire.begin();

  if (WiFi.status() == WL_NO_MODULE) {
    Serial.println("Communication with WiFi module failed!");
    while (true);
  }

  String fv = WiFi.firmwareVersion();
  if (fv < WIFI_FIRMWARE_LATEST_VERSION) {
    Serial.println("Please upgrade the firmware");
  }

  while (status != WL_CONNECTED) {
    Serial.print("Attempting to connect to SSID: ");
    Serial.println(ssid);
    status = WiFi.begin(ssid, pass);
    delay(10000);
  }

  server.begin();
  printWifiStatus();

  while (true) {
    WiFiClient client = server.available();
    if (client) {
      Serial.println("new client");
      bool currentLineIsBlank = true;

      while (client.connected()) {
        if (client.available()) {
          char c = client.read();
          Serial.write(c);
          if (c == '\n' && currentLineIsBlank) {
            // Citim distanța de la TF-Luna
            Wire.beginTransmission(deviceAddress);
            Wire.write(0x00);
            Wire.endTransmission();

            Wire.requestFrom((uint8_t)deviceAddress, (uint8_t)7);

            unsigned int distance = 0;
            unsigned int signalStrength = 0;

            if (Wire.available() == 7) {
              byte data[7];
              for (int i = 0; i < 7; i++) {
                data[i] = Wire.read();
              }

              distance = (data[1] << 8) | data[0];
              signalStrength = (data[3] << 8) | data[2];
            }

            // Răspunsul HTTP
            client.println("HTTP/1.1 200 OK");
            client.println("Content-Type: text/html");
            client.println("Connection: close");
            client.println("Refresh: 5");
            client.println();
            client.println("<!DOCTYPE HTML>");
            client.println("<html>");
            client.print("Distance: ");
            client.print(distance);
            client.println(" cm<br />");
            client.print("Signal Strength: ");
            client.print(signalStrength);
            client.println("<br />");
            client.println("</html>");
            break;
          }

          if (c == '\n') {
            currentLineIsBlank = true;
          } else if (c != '\r') {
            currentLineIsBlank = false;
          }
        }
      }
      delay(1);
      client.stop();
      Serial.println("client disconnected");
    }
    vTaskDelay(1);
  }
}
