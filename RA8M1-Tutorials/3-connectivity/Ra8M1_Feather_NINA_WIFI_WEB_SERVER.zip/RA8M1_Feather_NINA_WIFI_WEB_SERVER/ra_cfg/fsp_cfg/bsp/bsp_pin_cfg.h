/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define D14 (BSP_IO_PORT_00_PIN_00)
#define A5 (BSP_IO_PORT_00_PIN_04)
#define A4 (BSP_IO_PORT_00_PIN_05)
#define A3 (BSP_IO_PORT_00_PIN_06)
#define A2 (BSP_IO_PORT_00_PIN_07)
#define A1 (BSP_IO_PORT_00_PIN_08)
#define A0 (BSP_IO_PORT_00_PIN_14)
#define D10 (BSP_IO_PORT_01_PIN_12)
#define D11 (BSP_IO_PORT_01_PIN_13)
#define D12 (BSP_IO_PORT_01_PIN_14)
#define D13 (BSP_IO_PORT_01_PIN_15)
#define USB_VBUS (BSP_IO_PORT_04_PIN_07)
#define D5 (BSP_IO_PORT_04_PIN_08)
#define MISO (BSP_IO_PORT_04_PIN_10)
#define MOSI (BSP_IO_PORT_04_PIN_11)
#define SCK (BSP_IO_PORT_04_PIN_12)
#define D6 (BSP_IO_PORT_04_PIN_14)
#define D9 (BSP_IO_PORT_04_PIN_15)
extern const ioport_cfg_t g_bsp_pin_cfg; /* RA8M1_FEATHER */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER
#endif /* BSP_PIN_CFG_H_ */
