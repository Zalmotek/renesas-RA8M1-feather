/* generated configuration header file - do not edit */
#ifndef R_WDT_CFG_H_
#define R_WDT_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define WDT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define WDT_CFG_REGISTER_START_NMI_SUPPORTED ((0))

#ifdef __cplusplus
            }
            #endif
#endif /* R_WDT_CFG_H_ */
