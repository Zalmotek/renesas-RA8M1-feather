/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define ARDUINO_A0_MIKROBUS_AN (BSP_IO_PORT_00_PIN_00)
#define ARDUINO_A1 (BSP_IO_PORT_00_PIN_01)
#define ARDUINO_A2 (BSP_IO_PORT_00_PIN_02)
#define ARDUINO_A3 (BSP_IO_PORT_00_PIN_03)
#define USER_SW1 (BSP_IO_PORT_00_PIN_04)
#define USER_SW2 (BSP_IO_PORT_00_PIN_15)
#define ARDUINO_MISO_MIKROBUS_MISO_PMOD1_MISO (BSP_IO_PORT_01_PIN_00)
#define ARDUINO_MOSI_MIKROBUS_MOSI_PMOD1_MOSI (BSP_IO_PORT_01_PIN_01)
#define ARDUINO_CLK_MIKROBUS_CLK_PMOD1_CLK (BSP_IO_PORT_01_PIN_02)
#define ARDUINO_SS_MIKROBUS_SS_PMOD1_SS (BSP_IO_PORT_01_PIN_03)
#define ARDUINO_D3 (BSP_IO_PORT_01_PIN_04)
#define PMOD1_IO1 (BSP_IO_PORT_01_PIN_05)
#define PMOD1_IO2 (BSP_IO_PORT_01_PIN_06)
#define ARDUINO_D4 (BSP_IO_PORT_01_PIN_07)
#define ARDUINO_D9 (BSP_IO_PORT_01_PIN_12)
#define ARDUINO_D7 (BSP_IO_PORT_01_PIN_13)
#define ARDUINO_TX_MIKROBUS_TX (BSP_IO_PORT_02_PIN_05)
#define ARDUINO_RX_MIKROBUS_RX (BSP_IO_PORT_02_PIN_06)
#define PMOD1_RST (BSP_IO_PORT_02_PIN_08)
#define GROVE1_SCL_QWIIC_SCL (BSP_IO_PORT_03_PIN_01)
#define GROVE1_SDA_QWIIC_SDA (BSP_IO_PORT_03_PIN_02)
#define PMOD2_RST (BSP_IO_PORT_03_PIN_03)
#define PMOD2_IO2 (BSP_IO_PORT_03_PIN_04)
#define PMOD2_SCK (BSP_IO_PORT_04_PIN_00)
#define PMOD2_TXD (BSP_IO_PORT_04_PIN_01)
#define PMOD2_RXD (BSP_IO_PORT_04_PIN_02)
#define PMOD2_CTS (BSP_IO_PORT_04_PIN_03)
#define ARDUINO_SDA_MIKROBUS_SDA (BSP_IO_PORT_04_PIN_07)
#define ARDUINO_SCL_MIKROBUS_SCL (BSP_IO_PORT_04_PIN_08)
#define PMOD2_INT (BSP_IO_PORT_04_PIN_09)
#define PMOD2_CS2 (BSP_IO_PORT_04_PIN_10)
#define PMOD1_INT (BSP_IO_PORT_04_PIN_11)
extern const ioport_cfg_t g_bsp_pin_cfg; /* RA8M1 EK */
extern const ioport_cfg_t g_bsp_pin_cfg1; /* R7FA8M1AFECFP.pincfg_1 */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER
#endif /* BSP_PIN_CFG_H_ */
