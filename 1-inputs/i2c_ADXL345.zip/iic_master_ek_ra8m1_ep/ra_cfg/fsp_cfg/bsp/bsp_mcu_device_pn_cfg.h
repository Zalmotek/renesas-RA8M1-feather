/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA8M1AFECFP
#define BSP_MCU_FEATURE_SET ('A')
#define BSP_ROM_SIZE_BYTES (1048576)
#define BSP_RAM_SIZE_BYTES (917504)
#define BSP_DATA_FLASH_SIZE_BYTES (12288)
#define BSP_PACKAGE_QFP
#define BSP_PACKAGE_PINS (100)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
